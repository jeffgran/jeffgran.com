LoyaltyPlus
===========


### Instructions to run

1. `$ unzip lp.zip`
2. `$ cd lp`
3. `$ bundle install`
4. `$ bin/lp`

It should be pretty self-explanatory from there. There are a variety of commands you can run to enroll users, add transactions, etc.

To run tests, just run `$ rspec spec/`


### My Approach

I decided to just use plain-old-ruby-objects for this exercise since that keeps the project more self-contained, and the instructions specified that durable persistence wasn't necessary. The AccountRegistry is a singleton and it is the exterior-facing interface to the application. 

I started by stubbing in the three main commands I saw in the example input: `enroll`, `record`, and `redeem`. I used test-driven development to ensure those three methods worked right and tried to test the edge cases I could think of.

Since the example input in the instructions looked like command-line commands, I decided to model the UI as a REPL where you can just type the commands and the app parses them and interprets them. I used a combination of the Thor gem and the HighLine gem to make a custom LoyaltyPlus console.



### Commentary

I decided to raise exceptions when things went wrong (like a non-existent account id or member email) rather than just returning nil. I think it works pretty well for this application. Those truly are exceptional cases because the command the user is trying to execute is impossible to complete, and bubbling up custom error types to the "UI" lets the UI tell the user what went wrong processing the request.

I tried to be security-conscious and defensive. For example, 

- when returning a list of the transactions for a user, I didn't want them to be mutable because client code could accidentally (or intentionally) change them after the fact. 
- I put a list of the valid transaction types and checked incoming transactions against it, so that it would be impossible to put "bad" data, where the transaction type was misspelled or nonexistent.


I admit that the way I modeled the transactions and redemptions is a bit odd. I am keeping a list of transactions that is only the "earn" part of the earn/burn duality. The redemptions are kept in a second array (without timestamps -- would go back and add timestamps to that if I had time). I did it this way because I didn't want to lose any data. We want to keep a history of all of the transactions and when they happened, but we also had the requirement that we redeem the individual transactions in FIFO order in addition to figuring out the final balance. So keeping the credits and debits separately makes it easier to keep the history of both and also do the dual-loop algorithm to calculate which redemptions applied to which transactions. 

I implemented the balance calculation and the algorithm to calculate which transactions have been redeemed in a lazy, functional style. It always recalculates from first principles. This will always be correct as long as the tests are testing it correctly and doesn't suffer from the possibility of losing data by updating something incorrectly in-situ. But it has potential performance problems of course. In real life you might want to cache the result and update it incrementally if the list of transactions gets long enough and the access patterns are such that calculating those becomes a bottleneck. 

"The FOS secret_key in LoyaltyPlus is 123" -- this was only mentioned in one place, and I didn't know what it would be used for. It was not part of any of the specification so I ignored it.
