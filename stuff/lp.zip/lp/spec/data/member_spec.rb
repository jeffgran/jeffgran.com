require 'rspec'
require_relative '../../lib/data/member.rb'

describe Member do
  it 'adds purchases and redeems points, returning the correct balance each time' do

    m = Member.new(email: "auser@example.com")

    m.record(record_type: 'purchase', amount: 50)

    expect(m.balance).to eq 50

    m.record(record_type: 'purchase', amount: 25)

    expect(m.balance).to eq 75

    m.record(record_type: 'purchase', amount: 50)

    expect(m.balance).to eq 125

    m.redeem(100)

    expect(m.balance).to eq 25

    expect{m.redeem(100)}.to raise_error(Member::InsufficientFunds)
  end

  it "can tell you which transactions' points have been redeemed and redeems them in FIFO order" do

    m = Member.new(email: "auser@example.com")

    m.record(record_type: 'purchase', amount: 50)
    m.record(record_type: 'purchase', amount: 25)
    m.record(record_type: 'purchase', amount: 50)
    m.redeem(100)

    transactions = m.transactions

    t0 = transactions[0]
    expect(t0[:amount]).to eq 50
    expect(t0[:amount_redeemed]).to eq 50

    t1 = transactions[1]
    expect(t1[:amount]).to eq 25
    expect(t1[:amount_redeemed]).to eq 25

    t2 = transactions[2]
    expect(t2[:amount]).to eq 50
    expect(t2[:amount_redeemed]).to eq 25

  end

  it "rejects an otherwise valid redemption if the balance is less than 100" do

    m = Member.new(email: "auser@example.com")
    m.record(record_type: 'purchase', amount: 50)

    expect { m.redeem(25) }.to raise_error(Member::NotEligibleForRedemption)

  end

end
