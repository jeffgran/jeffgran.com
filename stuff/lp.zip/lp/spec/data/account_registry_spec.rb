require 'rspec'
require_relative '../../lib/data/account_registry.rb'

describe AccountRegistry do

  before(:each) do
    AccountRegistry.reset!
  end

  describe "#enroll" do

    it "enrolls a user with correct arguments" do
      expect {AccountRegistry.enroll(account_id: 'aabacd', email: 'auser@example.com')}.to_not raise_error
      member = AccountRegistry.get_member(account_id: 'aabacd', email: 'auser@example.com')
      expect(member).to_not be nil
      expect(member).to be_a Member
      expect(member.email).to eq 'auser@example.com'
    end

    it "rejects enrollment when email is missing" do
      expect { AccountRegistry.enroll(account_id: 'aabacd') }.to raise_error(ArgumentError)
    end

    it "rejects enrollment when email is missing" do
      expect { AccountRegistry.enroll(account_id: 'foobar', email: 'auser@example.com') }.to raise_error(AccountRegistry::InvalidAccountId)
    end

    it "rejects enrollment for duplicate email" do
      expect {AccountRegistry.enroll(account_id: 'aabacd', email: 'auser@example.com')}.to_not raise_error
      expect {AccountRegistry.enroll(account_id: 'aabacd', email: 'auser@example.com')}.to raise_error(AccountRegistry::DuplicateMember)
    end

  end

  describe "#record" do

    it "works with correct parameters" do
      AccountRegistry.enroll(account_id: 'aabacd', email: 'auser@example.com')

      expect {AccountRegistry.record(account_id: 'aabacd', email: 'auser@example.com', record_type: 'purchase', amount: 100)}.to_not raise_error
    end

    it "adds a transaction to the user" do
      AccountRegistry.enroll(account_id: 'aabacd', email: 'auser@example.com')

      expect {
        AccountRegistry.record(account_id: 'aabacd', email: 'auser@example.com', record_type: 'purchase', amount: 100)
      }.to change {
        AccountRegistry.get_member(account_id: 'aabacd', email: 'auser@example.com').transactions.size
      }.by(1)
    end

    it 'rejects the transaction for missing params' do
      AccountRegistry.enroll(account_id: 'aabacd', email: 'auser@example.com')

      expect {
        AccountRegistry.record(account_id: 'aabacd', email: 'auser@example.com')
      }.to raise_error(ArgumentError)
    end

    it 'rejects the transaction if a bad account id is supplied' do
      AccountRegistry.enroll(account_id: 'aabacd', email: 'auser@example.com')

      expect {
        AccountRegistry.record(account_id: 'foobar', email: 'auser@example.com', record_type: 'purchase', amount: 100)
      }.to raise_error(AccountRegistry::InvalidAccountId)
    end

    it 'rejects the transaction if a bad email is supplied' do
      AccountRegistry.enroll(account_id: 'aabacd', email: 'auser@example.com')

      expect {
        AccountRegistry.record(account_id: 'aabacd', email: 'buser@example.com', record_type: 'purchase', amount: 100)
      }.to raise_error(AccountRegistry::NoSuchMember)
    end

    it 'rejects the transaction if a bad record type is supplied' do
      AccountRegistry.enroll(account_id: 'aabacd', email: 'auser@example.com')

      expect {
        AccountRegistry.record(account_id: 'aabacd', email: 'auser@example.com', record_type: 'magic', amount: 100)
      }.to raise_error(Member::InvalidRecordType)
    end

  end

  describe "#redeem" do

    it "works with correct params" do
      AccountRegistry.enroll(account_id: 'aabacd', email: 'auser@example.com')
      AccountRegistry.record(account_id: 'aabacd', email: 'auser@example.com', record_type: 'purchase', amount: 100)
      expect {
        AccountRegistry.redeem(account_id: 'aabacd', email: 'auser@example.com', amount: 100)
      }.to_not raise_error
    end

    it "returns the member" do
      AccountRegistry.enroll(account_id: 'aabacd', email: 'auser@example.com')
      AccountRegistry.record(account_id: 'aabacd', email: 'auser@example.com', record_type: 'purchase', amount: 100)
      m = AccountRegistry.redeem(account_id: 'aabacd', email: 'auser@example.com', amount: 20)
      expect(m).to be_a Member
      expect(m.balance).to eq 80
    end

  end

end
