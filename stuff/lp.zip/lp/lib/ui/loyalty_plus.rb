require_relative '../data/account_registry'
require 'thor'

class LoyaltyPlus < Thor

  # override Thor's basename so help doesn't show the command prefix like `lp enroll ACCOUNT_ID EMAIL`
  # since we are not running individual command from bash shell
  def self.basename
    ""
  end

  desc "enroll <ACCOUNT_ID> <EMAIL>", "enroll a member in a loyalty program"
  def enroll(acct_id, email)
    member = AccountRegistry.enroll(account_id: acct_id, email: email)
    puts "=> Enrolled member"
    puts "#{acct_id} #{email} #{member.balance}"
  rescue => e
    puts "ERROR: Something went wrong: #{e.class.name}"
  end

  desc "record <ACCOUNT_ID> <EMAIL> <RECORD_TYPE> <AMOUNT>", "record a transaction for the specified member"
  def record(acct_id, email, record_type, amount)
    raise ArgumentError unless amount.to_i.to_s == amount
    member = AccountRegistry.record(account_id: acct_id, email: email, record_type: record_type, amount: amount.to_i)
    puts "=> Recorded transaction"
    puts "#{acct_id} #{email} #{member.balance}"
  rescue => e
    puts "ERROR: Something went wrong: #{e.class.name}"
  end

  desc "redeem <ACCOUNT_ID> <EMAIL> <AMOUNT>", "redeem the given amount of points from the given member's balance"
  def redeem(acct_id, email, amount)
    raise ArgumentError unless amount.to_i.to_s == amount
    member = AccountRegistry.redeem(account_id: acct_id, email: email, amount: amount.to_i)
    puts "=> Recorded transaction"
    puts "#{acct_id} #{email} #{member.balance}"
  rescue => e
    puts "ERROR: Something went wrong: #{e.class.name}"
  end

  desc "balance <ACCOUNT_ID> <EMAIL>", "check the balance for the given member"
  def balance(acct_id, email)
    member = AccountRegistry.get_member(account_id: acct_id, email: email)
    puts "#{acct_id} #{email} #{member.balance}"
  end

  desc "transactions <ACCOUNT_ID> <EMAIL>", "displays the full list of transactions for the given member, showing which points have been redeemed"
  def transactions(acct_id, email)
    member = AccountRegistry.get_member(account_id: acct_id, email: email)
    puts "----------------------"
    member.transactions.each do |t|
      puts "Timestamp       : #{t[:timestamp]}"
      puts "Transaction type: #{t[:record_type]}"
      puts "Amount          : #{t[:amount]}"
      puts "Amount redeemed : #{t[:amount_redeemed] || 0}"
      puts "----------------------"
    end
    puts "#{acct_id} #{email} #{member.balance}"
  end

  desc "exit", "exits the program. None of your progress will be saved."
  def exit
    raise SystemExit
  end

end
