class Member

  class InvalidRecordType < StandardError; end
  class InsufficientFunds < StandardError; end
  class NotEligibleForRedemption < StandardError; end

  RECORD_TYPES = [
    'purchase'
  ]

  def initialize(email:)
    @email = email
    @transactions = []
    @redemptions = []
  end

  def email
    @email.clone.freeze
  end

  # returns a copy of the transactions with each transaction marked with
  # how many of its points have been redeemed
  #
  def transactions
    # poor man's deep clone. we don't want this to be modified outside this
    # class, so this effectively makes this "read only"
    transactions = Marshal.load(Marshal.dump(@transactions))

    ti = 0
    @redemptions.each do |redemption|
      r = redemption

      until r == 0 do
        t = transactions[ti]
        t[:amount_redeemed] ||= 0
        amt_left = t[:amount] - t[:amount_redeemed]
        amt_to_redeem = [amt_left, r].min
        t[:amount_redeemed] += amt_to_redeem
        if t[:amount_redeemed] == t[:amount]
          ti += 1 # this one is spent, so move on to the next one
        end
        r = r - amt_to_redeem
      end
    end

    transactions
  end

  def record(record_type:, amount:)
    raise InvalidRecordType unless RECORD_TYPES.include?(record_type)

    @transactions.push({
        timestamp: Time.now.to_s,
        record_type: record_type,
        amount: amount
      })
  end

  def redeem(amount)
    raise InsufficientFunds if amount > balance
    raise NotEligibleForRedemption if balance < 100
    @redemptions.push(amount)
    balance
  end

  def balance
    @transactions.reduce(0){ |sum, t| sum + t[:amount] } - @redemptions.reduce(0, &:+)
  end

end
