require_relative './member'

class AccountRegistry

  class InvalidAccountId < StandardError; end
  class NoSuchMember < StandardError; end
  class DuplicateMember < StandardError; end

  class << self
    def enroll(account_id:, email:)
      raise DuplicateMember unless get_member(account_id: account_id, email: email).nil?

      acct = @@accounts[account_id]

      m = Member.new(email: email)
      acct[:members].push(m)
      m
    end

    def get_member(account_id:, email:)
      raise InvalidAccountId unless acct = @@accounts[account_id]

      acct[:members].detect do |member|
        member.email == email
      end
    end

    def record(account_id:, email:, record_type:, amount:)
      raise NoSuchMember unless member = get_member(account_id: account_id, email: email)

      member.record(record_type: record_type, amount: amount)

      member
    end

    def redeem(account_id:, email:, amount:)
      raise NoSuchMember unless member = get_member(account_id: account_id, email: email)

      amount_redeemed = member.redeem(amount)

      member
    end

    # useful for testing
    def reset!
      @@accounts = default_accounts
    end

    protected

    def default_accounts
      {
        'aabacd' => {
          name: 'Frontier Rewards',
          members: []
        }
      }
    end

  end

  @@accounts = self.default_accounts

end
